package com.sauravcodes.store;

import com.sauravcodes.entities.Address;
import com.sauravcodes.entities.User;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class StoreApplication {

    public static void main(String[] args) {

       //ApplicationContext context = SpringApplication.run(StoreApplication.class, args);
        var user = new User(1L, "name", "email", "password");
        user.setName("John");
        user.setEmail("John@gmail.com");
        user.setPassword("sdhf");

        var address = Address.builder()
                .street("street")
                .city("city")
                .state("state")
                .zip("zip")
                .build();

        user.addAddress(address);
        System.out.println(user);

    }

}
